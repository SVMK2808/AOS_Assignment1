#include<stdc++.h>
#include<unistd.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<iostream>
using namespace std;
void displaypermissions1(char *pathname){
    struct stat s1;
    if(stat(pathname, &s1) != 0){
        perror("Unable to get file info");
        exit(EXIT_FAILURE);
    }if(S_ISDIR(s1.st_mode)){
        if((s1.st_mode & S_IRUSR) != 0){ 
        string s = "\n\nUser has read permissions on directory: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nUser has read permissions on directory: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IWUSR) != 0){ 
        string s = "\n\nUser has write permissions on directory: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nUser has write permissions on directory: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IXUSR) != 0){ 
        string s = "\n\nUser has execute permissions on directory: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nUser has execute permissions on directory: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IRGRP) != 0){ 
        string s = "\n\nGroup has read permissions on directory: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nGroup has read permissions on directory: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IWGRP) != 0){ 
        string s = "\n\nGroup has write permissions on directory: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nGroup has write permissions on directory : No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IXGRP) != 0){ 
        string s = "\n\nGroup has execute permissions on directory: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nGroup has execute permissions on directory: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IROTH) != 0){ 
        string s = "\n\nOthers have read permissions on directory: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nOthers have read permissions on directory: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

}
}

void displaypermissions2(char *pathname){
    struct stat s1;
    if(stat(pathname, &s1) != 0){
        perror("Unable to get file info");
        exit(EXIT_FAILURE);
    }
    if((s1.st_mode & S_IRUSR) != 0){ 
        string s = "\n\nUser has read permissions on oldfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nUser has read permissions on oldfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IWUSR) != 0){ 
        string s = "\n\nUser has write permissions on oldfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nUser has write permissions on oldfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IXUSR) != 0){ 
        string s = "\n\nUser has execute permissions on oldfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nUser has execute permissions on oldfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IRGRP) != 0){ 
        string s = "\n\nGroup has read permissions on oldfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nGroup has read permissions on oldfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IWGRP) != 0){ 
        string s = "\n\nGroup has write permissions on oldfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nGroup has write permissions on oldfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IXGRP) != 0){ 
        string s = "\n\nGroup has execute permissions on oldfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nGroup has execute permissions on oldfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IROTH) != 0){ 
        string s = "\n\nOthers have read permissions on oldfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nOthers have read permissions on oldfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IWOTH) != 0){ 
        string s = "\n\nOthers has write permissions on oldfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nOthers has write permissions on oldfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IXOTH) != 0){ 
        string s = "\n\nOthers have execute permissions on oldfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nOthers have execute permissions on oldfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }
    }

    void displaypermissions3(char *pathname){
        struct stat s1;
        if(stat(pathname, &s1) != 0){
                  perror("Unable to get file info");
        exit(EXIT_FAILURE);
        }
         if((s1.st_mode & S_IRUSR) != 0){ 
        string s = "\n\nUser has read permissions on newfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nUser has read permissions on newfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IWUSR) != 0){ 
        string s = "\n\nUser has write permissions on newfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nUser has write permissions on newfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IXUSR) != 0){ 
        string s = "\n\nUser has execute permissions on newfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
         }else{
        string s = "\n\nUser has execute permissions on newfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
         cout<<s1.st_mode;
  
    }

     if((s1.st_mode & S_IRGRP) != 0){ 
        string s = "\n\nGroup has read permissions on newfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nGroup has read permissions on newfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IWGRP) != 0){ 
        string s = "\n\nGroup has write permissions on newfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nGroup has write permissions on newfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IXGRP) != 0){ 
        string s = "\n\nGroup has execute permissions on newfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nGroup has execute permissions on newfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IROTH) != 0){ 
        string s = "\n\nOthers have read permissions on newfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nOthers have read permissions on newfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IWOTH) != 0){ 
        string s = "\n\nOthers has write permissions on newfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nOthers has write permissions on newfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

     if((s1.st_mode & S_IXOTH) != 0){ 
        string s = "\n\nOthers have execute permissions on newfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "\n\nOthers have execute permissions on newfile: No \n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }
   

    }



int main(int argc, char *argv[]){

    if(argc < 4){
        perror("Insufficient no. of argumnents");
        exit(EXIT_FAILURE);
    }

    int fp1 = open(argv[1], O_RDONLY);

    if(fp1 < 0){
        perror("Unable to open the file in read mode");
        close(fp1);
        exit(EXIT_FAILURE);
    }

    int fp2 = open(argv[2], O_RDONLY);

    if(fp1 < 0){
        perror("Unable to open the file in read mode");
        close(fp1);
        exit(EXIT_FAILURE);
    }
    

    
    ssize_t filesize1 = lseek(fp1, 0, SEEK_END);
    ssize_t filesize2 = lseek(fp2, 0, SEEK_END);

    lseek(fp2, 0, SEEK_SET);
    



    
    const ssize_t CHUNK_SIZE = 5;
        char buff1[CHUNK_SIZE];
        long long res = CHUNK_SIZE;
        char buff2[CHUNK_SIZE];

    bool flag = true;

    ssize_t temp1 = filesize1;
    ssize_t temp2 = filesize2;

     int c = 0;


while(filesize1>0){
    if(filesize1 <= res){
        res = filesize1;
    }

    ssize_t bytesprocessed = 0;

    if(lseek(fp1, filesize1 - res, SEEK_SET) == -1){
            perror("Unable to get to the desired position");
            close(fp1);
            close(fp2);
            exit(EXIT_FAILURE);
        }

           if(lseek(fp2, 0, SEEK_CUR) == -1){
            perror("Unable to get to the desired position");
            close(fp1);
            close(fp2);
            exit(EXIT_FAILURE);
        }


   
        ssize_t bytesread1 = read(fp1, buff1, res);
        ssize_t bytesread2 = read(fp2, buff2, res);
        
        if(bytesread1 == -1 || bytesread2 == -1){
            perror("Error reading the file");
            close(fp1);
            close(fp2);
            exit(EXIT_FAILURE);
        }


        for(int i = res-1,j = 0; i>=0 && j<res; i--, j++){
            cout<<buff1[i]<<" "<<buff2[j]<<"\n";
            if(buff1[i] != buff2[j]){
                flag = false;
                c = i;
                break;
            }
        }

        if(!flag)
        break;
        filesize1 -= res;
        
    }


    struct stat f;
    if(stat(argv[3], &f) != 0){
        perror("Unable to get the directory info");
        close(fp1);
        close(fp2);
        exit(EXIT_FAILURE);
    } else if((f.st_mode & S_IFDIR) != 0){
        string s = "Directory is created: Yes";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "Directory is created: No";
        write(STDOUT_FILENO, s.c_str(), s.size());
        exit(EXIT_FAILURE);
    }


    struct stat s1, s2;

    if(stat(argv[1], &s1) != 0){
        perror("Error getting the size of the file");
        exit(EXIT_FAILURE);
    }

    if(stat(argv[2], &s2) != 0){
        perror("Error getting the size of file1");
        exit(EXIT_FAILURE);
    }

   
    if(temp1 == temp2){
        string s = "\n\n Both Files Sizes are Same : Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());

    }else{
        string s = "\n\n Both Files Sizes are Same : No\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }

        if(flag == true){
        string s = "Whether file contents are reversed in oldfile: Yes\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
    }else{
        string s = "Whether file contents are reversed in oldfile: No\n";
        write(STDOUT_FILENO, s.c_str(), s.size());
        cout<<c;
    }


    displaypermissions1(argv[3]);
    displaypermissions2(argv[2]);
    displaypermissions3(argv[1]);

    close(fp1);
    close(fp2);
    exit(EXIT_SUCCESS);

}