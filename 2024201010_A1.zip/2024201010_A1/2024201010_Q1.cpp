#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdc++.h>
#include <cstring>
#include <iostream>
#include <string>
using namespace std;

int main(int argc, char *argv[])
{
      if (argc < 3)
    {
        perror("Insufficient arguments");
        exit(EXIT_FAILURE);
    }
     int fp = open(argv[1], O_RDONLY);
   
    if (fp < 0)
    {
        perror("Unable to create a file in read mode");
        exit(EXIT_FAILURE);
    }

    string file_name;

    int i;

    for (i = 0; argv[1][i] != '\0'; i++);
    i--;

    /* for(i = 0; argv[1][i] != argv[1][0]; i++);
     i--; */

    int j;

    for (j = i; argv[1][j] != '/'; j--);

    j++;

    for (int k = j; k <= i; k++)
    {
        file_name += argv[1][k];
    }

    int flag = stol(argv[2]);

    if (flag == 0)
    {
         if (mkdir("Assignment1", 0700) < 0)
        {
            perror("mkdir");
            close(fp);
            exit(EXIT_FAILURE);
        }

        string r = "Assignment1/0_";
        r += file_name;
        const char *r1 = r.c_str();
        int wfp = open(r1, O_CREAT | O_WRONLY, S_IRWXU);
        if (wfp == -1)
        {
            perror("Unable to create the output file");
            close(fp);
            exit(EXIT_FAILURE);
        }

        if (mkdir("Assignment1", 0700) < 0)
            perror("mkdir");

        off_t filesize = lseek(fp, 0, SEEK_END);
        cout<<"a";
        if (filesize == -1)
        {
            perror("Unable to get the file size");
            close(wfp);
            close(fp);
            exit(EXIT_FAILURE);
        }
        const ssize_t CHUNK_SIZE = 1024*1024+5;
        char buff[CHUNK_SIZE];
        ssize_t res = CHUNK_SIZE;
        ssize_t temp = filesize;
        ssize_t count = 0;

     
        while (filesize > 0)
        {
            if (filesize <= res)
            {
                res = filesize;
            }
            if (lseek(fp, filesize-res, SEEK_SET) == -1)
            {
                perror("Unable to set file position");
                close(wfp);
                close(fp);
                exit(EXIT_FAILURE);
            }

            ssize_t bytes_read = read(fp, buff, res);
            if (bytes_read == -1)
            {
                perror("Error reading the file");
                close(wfp);
                close(fp);
                exit(EXIT_FAILURE);
            }
            
            for (ssize_t i = bytes_read - 1; i >= 0; i--)
            {

                if (write(wfp, &buff[i], 1) != 1)
                {
                    perror("Error writing to the file");
                    close(wfp);
                    close(fp);
                    exit(EXIT_FAILURE);
                }
            }
             count+=res;
            float per = ((double)count/(double)temp)*100;
            cout<<"\r"<<"Progress : "<<per<<flush;
            
            filesize -= res;
        }
        close(wfp);
    }
    
    if (flag == 1)
    {
         const char *it1 = argv[3];
    const char *it2 = argv[4];
    long start_ind = stoi(it1);
    long end_ind = stoi(it2);

       
     
        if (mkdir("Assignment1", 0700) < 0)
        {
            perror("mkdir");
            close(fp);
            exit(EXIT_FAILURE);
        }

        string r = "Assignment1/1_";
        r += file_name;
        const char *r1 = r.c_str();
        int wfp = open(r1, O_CREAT | O_WRONLY, 00600);
        if (wfp == -1)
        {
            perror("Unable to create the output file");
            close(fp);
            exit(EXIT_FAILURE);
        }

        ssize_t filesize = lseek(fp, 0, SEEK_END);
        ssize_t temp = filesize;
        if (filesize == -1)
        {
            perror("Unable to get the file size");
            close(fp);
            close(wfp);
            exit(EXIT_FAILURE);
        }
        if(start_ind> end_ind || start_ind < 0 || end_ind <0 || end_ind > filesize -1){
        perror("invalid arguments");
        exit(EXIT_FAILURE);
     }

       long long a = lseek(fp, start_ind, SEEK_SET);
       
         const ssize_t CHUNK_SIZE = 2;
        char buff[CHUNK_SIZE];
        long long res = CHUNK_SIZE;
        int count = 0;

       while(a>0 ) 
        {
            if (a <= res)
            {
                res = a;
            }
        
            
            if (lseek(fp, a-res, SEEK_SET) == -1)
            {
                perror("Unable to set file position");
                close(wfp);
                close(fp);
                exit(EXIT_FAILURE);
            }

            ssize_t bytes_read1 = read(fp, buff, res);
            if (bytes_read1 == -1)
            {
                perror("Error reading the file");
                close(wfp);
                close(fp);
                exit(EXIT_FAILURE);
            }

            for (ssize_t i = bytes_read1 - 1; i >= 0; i--)
            {

                if (write(wfp, &buff[i], 1) != 1)
                {
                    perror("Error writing to the file");
                    close(wfp);
                    close(fp);
                    exit(EXIT_FAILURE);
                }

            }
            count+=res;
            float per = ((double)count/(double)temp)*100;
            cout<<"\r"<<"Progress "<<per<<flush;
                
            a-=res;
        }


       ssize_t b = end_ind - start_ind ;
        lseek(fp, start_ind, SEEK_SET);
        res = CHUNK_SIZE;
        char bufm[res];



        while(b>0){
            if(b <= res){
                res = b;
            }

            
            ssize_t bytesread2 = read(fp, bufm, res);
            if(bytesread2 == -1){
                perror("Unable to read from the file");
                close(fp);
                close(wfp);
                exit(EXIT_FAILURE);
            }

            for(ssize_t f = 0; f<bytesread2; f++){
                

                if(write(wfp, &bufm[f], 1) != 1){
                    perror("Unable to write from the file ");
                    close(fp);
                    close(wfp);
                    exit(EXIT_FAILURE);
                }else{
                    }

             }
             count+=res;
            float per = ((double)count/(double)temp)*100;
            cout<<"\r"<<"Progress "<<per<<flush;
            
              b -= res;
            }

            



        ssize_t c = lseek(fp, end_ind, SEEK_SET);
        ssize_t d = filesize;
        ssize_t e = d - c;
        res = CHUNK_SIZE;
        char bufe[res];

        lseek(fp, 0, SEEK_END);

       

        while(e != 0){
            if(e <= res){
                res = e;
            }
        

        if(lseek(fp, d-res, SEEK_SET) == -1){
            perror("Unable to get to the file position");
            close(fp);
            close(wfp);
            exit(EXIT_FAILURE);
        }

        ssize_t bytes_read3 = read(fp, bufe, res);
        if(bytes_read3 == -1){
            perror("Unable to read from the file");
            close(fp);
            close(wfp);
            exit(EXIT_FAILURE);
        }
        reverse(bufe, bufe + res);
        if(write(wfp, bufe, res) == -1){
            perror("Unable to write into the file");
            close(fp);
            close(wfp);
            exit(EXIT_FAILURE);
        }

         count+=res;
        float per = ((double)count/(double)temp)*100;
        cout<<"\r"<<"Progress "<<per<<flush;
        e -= res;
        d -= res;

         }

         close(wfp);
        

}

    close(fp);
    return 0;
}